local NPC = 29062;
local Ret = 0;

if (EVENT == 100) then
	
end