local NPC = 29064;
local Ret = 0;

if (EVENT == 100) then
	
end