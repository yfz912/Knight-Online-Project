local NPC = 29063;
local Ret = 0;

if (EVENT == 100) then
	
end