local Ret = 0;
local NPC = 16073;

if (EVENT == 168) then
	Ret = 1;
end

if (EVENT == 165) then
	SelectMsg(UID, 3, -1, 4480, NPC, 4201, 4201, 4202, 4202, 4203, 4203, 4204, 4204, 4205, 4205, 4206, 4206, 4207, 4207, 4208, 4208, 4209, 4209, 4210, 4210, 4211, 4211);        
end

if (EVENT == 4201) then
	SelectMsg(UID, 2, -1, 4481, NPC, 10, 168);        
end

if (EVENT == 4202) then
	SelectMsg(UID, 2, -1, 4482, NPC, 10, 168);        
end

if (EVENT == 4203) then
	SelectMsg(UID, 2, -1, 4483, NPC, 10, 168);        
end

if (EVENT == 4204) then
	SelectMsg(UID, 2, -1, 4484, NPC, 10, 168);        
end

if (EVENT == 4205) then
	SelectMsg(UID, 2, -1, 4485, NPC, 10, 168);        
end

if (EVENT == 4206) then
	SelectMsg(UID, 2, -1, 4486, NPC, 10, 168);        
end

if (EVENT == 4207) then
	SelectMsg(UID, 2, -1, 4487, NPC, 10, 168);        
end

if (EVENT == 4208) then
	SelectMsg(UID, 2, -1, 4488, NPC, 10, 168);        
end

if (EVENT == 4209) then
	SelectMsg(UID, 2, -1, 4489, NPC, 10, 168);        
end

if (EVENT == 4210) then
	SelectMsg(UID, 2, -1, 4490, NPC, 10, 168);        
end

if (EVENT == 4211) then
	SelectMsg(UID, 2, -1, 4491, NPC, 10, 168);        
end