local NPC = 29067;
local Ret = 0;

if (EVENT == 100) then
	
end