local UserClass;
local QuestNum;
local Ret = 0;
local NPC =29194;

if (EVENT == 100) then
	SelectMsg(UID, 3, -1, 10444, NPC, 7579, 100, 7580, 100, 7581, 100);
end