local NPC = 29068;
local Ret = 0;

if (EVENT == 100) then
	
end