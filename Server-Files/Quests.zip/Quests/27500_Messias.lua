if EVENT == 100 then
	SelectMsg(UID, 2, 886, 8667, 536, 10, 168, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
end




if EVENT == 536 then
   MonsterSub = ExistMonsterQuestSub(UID);
   if MonsterSub == 100 then
      SelectMsg(UID, 4, 886, 8667, 13013, 22, 9608, 23, 168, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
   else
      SelectMsg(UID, 2, 886, 8667, 13013, 10, 168, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
   end
end

if EVENT == 9608 then
    jdnhfjkdshndjskhfsk
end