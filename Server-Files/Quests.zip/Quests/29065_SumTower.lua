local NPC = 29065;
local Ret = 0;

if (EVENT == 100) then
	
end