local NPC = 29060;
local Ret = 0;

if (EVENT == 100) then
	
end